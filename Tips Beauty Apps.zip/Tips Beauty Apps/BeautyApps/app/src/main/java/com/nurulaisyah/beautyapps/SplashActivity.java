package com.nurulaisyah.beautyapps;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

public class SplashActivity extends AppCompatActivity {

    private ProgressBar loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        loading = findViewById(R.id.loadingSplash);

        //fungsi untuk mengatur berapa lama splash akan tampil
        Thread thread = new Thread(){
            public void run(){
                try{
                    sleep(2000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }finally {
                    UserSession x = new UserSession(SplashActivity.this);
                    if (x.getIsLogin()) {
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(SplashActivity.this, Login.class);
                        startActivity(intent);
                    }
                    finish();
                }
            }
        };
        thread.start();
        loading.setVisibility(View.VISIBLE);
    }
}
