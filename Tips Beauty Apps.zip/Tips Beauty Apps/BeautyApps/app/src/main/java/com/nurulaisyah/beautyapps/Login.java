package com.nurulaisyah.beautyapps;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    //definisasi view
    private EditText editTextEmail;
    private EditText editTextPass;
    private Context context;
    private AppCompatButton btnLogin;
    private ProgressDialog pDialog;
    ConnectionDetector conn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        context = Login.this;

        conn = new ConnectionDetector(getApplicationContext());

        //inisialisasi object
        pDialog = new ProgressDialog(context);
        editTextEmail = (EditText)findViewById(R.id.editTextEmail);
        editTextPass = (EditText)findViewById(R.id.editTextPassword);
        btnLogin = (AppCompatButton)findViewById(R.id.buttonLogin);
        LinearLayout llLogin = (LinearLayout) findViewById(R.id.ll_login);
        llLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, DaftarActivity.class);
                startActivity(intent);
            }
        });

        //menginisialisasi buttonLogin
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //jika btn di klik maka akan diarahkan ke method login()
                login();//fungsi button login
            }
        });
    }

    //method login yang nantinya akan di panggil pada fungsi btnLogin
    private void login() {
        //mengambil data dari id ke variabel atau field
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPass.getText().toString().trim();
        //proses ketika login berjalan
        pDialog.setMessage("Login Process . . .");
        //untuk menampilkan pesan diatas
        showDialog();

        if (conn.isConnected()) {
            //merequest method post dari AppVar
            StringRequest stringRequest = new StringRequest(Request.Method.POST, AppVar.LOGIN_URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    //jika login sucess maka akan diarahkan ke method hideDialog dan gotoFormActivity
                    if (response.contains(AppVar.LOGIN_SUCCESS)) {
                        hideDialog();
                        gotoFormActivity(response);
                    } else {
                        //jika email dan password belum diisi maka akan muncul
                        hideDialog();
                        Toast.makeText(context, "Invalid email and password!", Toast.LENGTH_LONG).show();
                    }
                }
            },      // jika tidak terhubung ke server
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            hideDialog();
                            Toast.makeText(context, "The server unreachable", Toast.LENGTH_LONG).show();
                        }
                    })
            {
                //memasukan value menggunakan key ke field atau variabel
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put(AppVar.KEY_EMAIL, email);
                    params.put(AppVar.KEY_PASSWORD, password);
                    return params;
                }
            };
            Volley.newRequestQueue(this).add(stringRequest);
        } else {
            pDialog.dismiss();
            Toast.makeText(getApplicationContext(), "Tidak ada internet", Toast.LENGTH_SHORT).show();
        }
    }

    int id, status;
    String no_hp, email, nama, gambar;
    //method untuk berpindah halaman setelah login berhasil
    private void gotoFormActivity(String response){
        try {
            JSONObject datas = new JSONObject(response);

            if (datas.getInt("success") == 1) {
                JSONArray x = datas.getJSONArray("data");
                for (int i = 0; i < x.length(); i++) {
                    JSONObject y = x.getJSONObject(i);
                    id = y.getInt("id");
                    email = y.getString("email");
                    no_hp = y.getString("no_hp");
                    nama = y.getString("accountname");
                    status = y.getInt("status");
                    gambar = y.getString("gambar");
                }

                UserSession z = new UserSession(getApplicationContext());
                z.setIsLogin(true);
                z.setId(id);
                z.setEmail(email);
                z.setNoHp(no_hp);
                z.setNama(nama);
                z.setStatus(status);
                if(gambar.equals("null")) {
                    z.setImageProfile(null);
                } else {
                    z.setImageProfile(gambar);
                }

                Intent i = new Intent(Login.this, MainActivity.class);
                startActivity(i);
                finish();
            } else {
                Toast.makeText(getApplicationContext(),
                        datas.getString("message"), Toast.LENGTH_LONG).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();;
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
