package com.nurulaisyah.beautyapps;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DaftarActivity extends AppCompatActivity {
    EditText etNama, etEmail, etNoHp, etPass, etKonfPass;
    AppCompatButton btnDaftar;
    ConnectionDetector conn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);
        conn = new ConnectionDetector(getApplicationContext());

        etNama = (EditText) findViewById(R.id.et_nama);
        etEmail = (EditText) findViewById(R.id.et_email);
        etNoHp = (EditText) findViewById(R.id.et_no_hp);
        etPass = (EditText) findViewById(R.id.et_pass);
        etKonfPass = (EditText) findViewById(R.id.et_kon_pass);
        btnDaftar = (AppCompatButton) findViewById(R.id.btn_daftar);
        LinearLayout ll_daftar = (LinearLayout) findViewById(R.id.ll_daftar);
        ll_daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnDaftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!etPass.getText().toString().equals(etKonfPass.getText().toString()) || !etKonfPass.getText().toString().equals(etPass.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Periksa kembali password yang anda masukkan", Toast.LENGTH_SHORT).show();
                } else {
                    final ProgressDialog pDialog = new ProgressDialog(DaftarActivity.this);
                    pDialog.setCancelable(false);
                    pDialog.setMessage("Tunggu Sebentar...");
                    pDialog.show();
                    if (conn.isConnected()) {
                        StringRequest stringRequest = new StringRequest(Request.Method.POST, AppVar.REGISTER_URL, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject datas = new JSONObject(response);
                                    if (datas.getInt("success") == 1) {
                                        final AlertDialog.Builder dialog = new AlertDialog.Builder(DaftarActivity.this);
                                        dialog.setCancelable(false);
                                        dialog.setIcon(R.drawable.ic_check_green_24dp);
                                        dialog.setTitle("Sukses");
                                        dialog.setMessage(datas.getString("message"));
                                        dialog.setPositiveButton("Oke", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                finish();
                                                dialogInterface.dismiss();
                                            }
                                        });
                                        dialog.setNegativeButton("Tetap disini", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int which) {
                                                dialogInterface.dismiss();
                                            }
                                        });
                                        dialog.show();
                                    } else {
                                        final AlertDialog.Builder dialog = new AlertDialog.Builder(DaftarActivity.this);
                                        dialog.setCancelable(false);
                                        dialog.setIcon(R.drawable.ic_alert);
                                        dialog.setTitle("Kesalahan");
                                        dialog.setMessage(datas.getString("message"));
                                        dialog.setPositiveButton("Oke", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                dialogInterface.dismiss();
                                            }
                                        });
                                        dialog.show();
                                    }
                                    pDialog.dismiss();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                if (error != null) {
                                    Toast.makeText(getApplicationContext(), "The server unreachable", Toast.LENGTH_LONG).show();
                                    Log.e("Error", error.toString());
                                }
                                pDialog.dismiss();
                            }
                        }) {
                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                Map<String, String> params = new HashMap<>();
                                params.put("email", etEmail.getText().toString().trim());
                                params.put("password", etPass.getText().toString().trim());
                                params.put("nama", etNama.getText().toString().trim());
                                params.put("no_hp", etNoHp.getText().toString().trim());
                                return params;
                            }
                        };
                        Volley.newRequestQueue(getApplicationContext()).add(stringRequest);
                    } else {
                        pDialog.dismiss();
                        Toast.makeText(getApplicationContext(), "Tidak ada internet", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
