package com.nurulaisyah.beautyapps;

public class AppVar {
    //URL yang digunakan untuk engakses data dari database
//    public static final String LOGIN_URL = "http://192.168.43.52/course/login.php";
    public static final String LOGIN_URL = "http://course.bdigy.com/login.php";
    public static final String REGISTER_URL = "http://course.bdigy.com/register.php";
    public static final String IMAGE_URL = "http://course.bdigy.com/img/";

    //Key yang digunakan untuk mengakses email dan password menggunakan POST di file login.php
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";

    //Jika server berhasil maka akan muncul hasil ini
    public static final String LOGIN_SUCCESS = "success";
}
