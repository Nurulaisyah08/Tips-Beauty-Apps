package com.nurulaisyah.beautyapps;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

public class AkunSayaFragment extends Fragment {

    public AkunSayaFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_akun_saya, container, false);
        TextView tvNama, tvEmail, tvNoHp;
        final ImageView ivAkun;
        final ProgressBar pbImage;

        tvNama = (TextView) view.findViewById(R.id.tv_name);
        tvEmail = (TextView) view.findViewById(R.id.tv_email);
        tvNoHp = (TextView) view.findViewById(R.id.tv_no_hp);
        ivAkun = (ImageView) view.findViewById(R.id.iv_akun_saya);
        pbImage = (ProgressBar) view.findViewById(R.id.pb_load_image);


        ((MainActivity) getActivity()).toolbar.setTitle("My Account");

        UserSession x = new UserSession(getActivity());
        tvNama.setText(x.getNama());
        tvEmail.setText(x.getEmail());
        tvNoHp.setText(x.getNoHp());

        Picasso.with(getActivity())
                .load(AppVar.IMAGE_URL + new UserSession(getActivity()).getImageProfile())
                .memoryPolicy(MemoryPolicy.NO_CACHE)
                .networkPolicy(NetworkPolicy.NO_CACHE)
                .into(ivAkun, new Callback() {
                    @Override
                    public void onSuccess() {
                        ivAkun.setVisibility(View.VISIBLE);
                        pbImage.setVisibility(View.GONE);
                    }

                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                    @Override
                    public void onError() {
                        ivAkun.setImageDrawable(getActivity().getDrawable(R.drawable.boy));
                        ivAkun.setVisibility(View.VISIBLE);
                        pbImage.setVisibility(View.GONE);
                    }
                });

        return view;
    }

}
