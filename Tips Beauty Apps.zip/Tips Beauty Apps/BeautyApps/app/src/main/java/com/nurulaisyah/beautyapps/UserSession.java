package com.nurulaisyah.beautyapps;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

/**
 * Created by user on 18-Aug-17.
 */

public class UserSession {

//    private final static UserSession instance;

    static {
//        instance = new UserSession();
    }

//    public static UserSession getInstance() {
//        return instance;
//    }

    private final SharedPreferences appPreference;

    public UserSession(Context context) {
        appPreference = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public void setSessionString(String key, String value) {
        SharedPreferences.Editor editor = appPreference.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public void setSessionInt(String key, int value) {
        SharedPreferences.Editor editor = appPreference.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public void clearSession() {
        SharedPreferences.Editor editor = appPreference.edit();
        editor.clear();
        editor.apply();
        editor.commit();
    }

    public String getSessionString(String key) {
        String value = appPreference.getString(key, null);
        if (TextUtils.isEmpty(value)) {
            return null;
        }
        return value;
    }

    public Integer getSessionInteger(String key) {
        int value = appPreference.getInt(key, 0);
        if (value == 0) {
            return 0;
        }
        return value;
    }

    public void setIsLogin(boolean stat) {
        SharedPreferences.Editor editor = appPreference.edit();
        editor.putBoolean("IS_LOGIN", stat);
        editor.apply();
    }

    public boolean getIsLogin() {
        boolean isLogin = appPreference.getBoolean("IS_LOGIN", false);
        return isLogin;
    }


    public Integer getId() {
        return getSessionInteger("id");
    }

    public void setId(int id) {
        setSessionInt("id", id);
    }

    public String getEmail() {
        return getSessionString("email");
    }

    public void setEmail(String email) {
        setSessionString("email", email);
    }

    public String getNoHp() {
        return getSessionString("no_hp");
    }

    public void setNoHp(String noHp) {
        setSessionString("no_hp", noHp);
    }

    public String getNama() {
        return getSessionString("accountname");
    }

    public void setNama(String nama) {
        setSessionString("accountname", nama);;
    }

    public Integer getStatus() {
        return getSessionInteger("status");
    }

    public void setStatus(int status) {
        setSessionInt("status", status);
    }

    public String getImageProfile() {
        return getSessionString("img_profile");
    }

    public void setImageProfile(String imgProfile) {
        setSessionString("img_profile", imgProfile);
    }


}


