<?php
	include_once "koneksi.php";

	class usr{}

	$nama = $_POST["nama"];
	$email = $_POST["email"];
	$no_hp = $_POST["no_hp"];
	$password = $_POST["password"];

	if(!$nama || !$email || !$no_hp || !$password)
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "Lengkapi form anda untuk melanjutkan!";
        die(json_encode($response));
     }
     else if(!preg_match("/^[a-zA-Z.',`]*$/", $nama))
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "Masukkan nama anda dengan benar!";
        die(json_encode($response));
     }
     else if(!preg_match("/^[a-zA-Z0-9_@.]*$/", $email))
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "email hanya boleh menggunakan huruf, angka dan garis bawah!";
        die(json_encode($response));
     }
     else if(!preg_match("/^[a-zA-Z0-9_@.,]*$/", $password))
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "Password hanya boleh menggunakan huruf dan angka!";
        die(json_encode($response));
     }
     else if(!preg_match("/^[0-9+]*$/", $no_hp))
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "Masukkan nomer handphone anda dengan benar!";
        die(json_encode($response));
     }
     else
     {
			$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM users WHERE email='".$email."'"));

			if ($num_rows == 0){
				$query = mysqli_query($con, "INSERT INTO users (password, email, no_hp, accountname, status) VALUES('".$password."', '".$email."', '".$no_hp."', '".$nama."', '1')");

				if ($query){
					$response = new usr();
					$response->success = 1;
					$response->message = "Register berhasil, silahkan login.";
					die(json_encode($response));

				} else {
					$response = new usr();
					$response->success = 0;
					$response->message = "Register gagal";
					die(json_encode($response));
				}
			} else {
				$response = new usr();
				$response->success = 0;
				$response->message = "Email sudah ada";
				die(json_encode($response));
			}
	}

	mysqli_close($con);
?>