<?php
     include_once "koneksi.php";
     class usr{}
     //$email='kasir';
     //$password='kasir';
     if(!$_POST['email'] || !$_POST['password'])
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "email atau password belum terisi!";
        die(json_encode($response));
     }
     else if(!preg_match("/^[a-zA-Z0-9_@.]*$/", $_POST['email']))
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "email hanya boleh menggunakan huruf, angka dan garis bawah!";
        die(json_encode($response));
     }
     else if(!preg_match("/^[a-zA-Z0-9_@.,]*$/", $_POST['password']))
     {
        $response = new usr();
        $response->success = 400;
        $response->message = "Password hanya boleh menggunakan huruf dan angka!";
        die(json_encode($response));
     }
     else
     {
         $email = $_POST['email'];
         $password = $_POST['password'];
    
         // if ((empty($email)) || (empty($password))) { 
         //      $response = new usr();
         //      $response->success = 0;
         //      $response->message = "Kolom tidak boleh kosong"; 
         //      die(json_encode($response));
         // }
    
         $query = mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND password='$password' AND status='1'");

         if (mysqli_num_rows($query) > 0){
              $response = new usr();
              $response = array();
              $response['success'] = 1;
              $response['message'] = "login berhasil";
              $response["data"] = array();
              while($row = mysqli_fetch_array($query)){
                   $h['id'] = $row["id"];
                   $h['email'] = $row["email"];
                   $h['no_hp'] = $row["no_hp"];
                   $h['accountname'] = $row["accountname"];
                   $h['status'] = $row["status"];
                   $h['gambar'] = $row["gambar"];
                   array_push($response["data"], $h);
              }
              die(json_encode($response));
    
         } else { 
              $response = new usr();
              $response['success'] = 400;
              $response['message'] = "email atau password salah";
              die(json_encode($response));
         }
     }
     mysqli_close($con);
?>