<?php
//$error='';
date_default_timezone_set('Asia/Jakarta');
$database = "dbcourse";
$con =mysqli_connect("localhost", "root", "", $database) or die ("Koneksi ke database gagal!");
?>